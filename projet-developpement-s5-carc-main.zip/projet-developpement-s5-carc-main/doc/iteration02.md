# Livraison 2

- # En terme de fonctionnalités livrées et issues faites
    - Ajout de tuiles (Issue #15)
        - Tuile de départ (Issue #13)
        - Tuile de route (Issue #14)
    - Mise à jour de l'IA primitive (Issue #17)
        - Placement de la tuile de départ pour le joueur de départ (Issue #16)
    - Mise à jour des composants de jeu (Issue #20)
        - Ajout du compteur de score pour chaque joueur (Issue #18)
        - Fin de la partie si la pioche est vide (Issue #19)


- # En terme de tests (en charge : Sébastien Aglae)
    - Mise à jour des anciens tests pour tester les nouvelles possibilités
    - Ajout de nouveaux tests pour vérifier la bonne implémentation des nouvlles fonctionnalités

- # En terme d'organisation de code
    - Ajout de tasks et de subtasks
    - Création de milestones

- # En terme d'organisation du travail (qui a fait quoi)
    - Assignation de chaque collaborateurs aux Issues sur GitHub
    - Mike Chiappe s'occupe de la gestion du projet et de driver les collaborateurs
