package client.logger;

public enum LogLevel {
    DEBUG,
    INFO,
    WARN,
    ERROR
}
