package logic.exception;

/**
 * Exception thrown when the number of players is too high.
 */
public class TooManyPlayerException extends RuntimeException {
}
